# GrainPalette: Rice Type Classification Through Transfer Learning

This project classifies different types of rice grains using transfer learning with TensorFlow/Keras.

## Project Structure
- `data/`: Dataset directory (place your rice images here).
- `notebooks/`: Step-by-step scripts for each phase.
- `model/`: Saved model files.
- `app/`: Streamlit application for inference.

## Setup

```bash
pip install -r requirements.txt
```

## Usage

1. **Data Preparation & Preprocessing**  
   Run the scripts in `notebooks/` in sequence.

2. **Training & Model Saving**  
   ```bash
   python notebooks/03_model_building.py
   python notebooks/04_save_model.py
   ```

3. **Launch App**  
   ```bash
   streamlit run app/app.py
   ```

