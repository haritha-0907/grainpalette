import streamlit as st
import tensorflow as tf
import numpy as np
import cv2

st.title("GrainPalette Rice Type Classifier")

model = tf.keras.models.load_model('../model/grainpalette_model.h5')

uploaded_file = st.file_uploader("Upload Rice Grain Image", type=['png','jpg','jpeg'])
if uploaded_file:
    file_bytes = np.asarray(bytearray(uploaded_file.read()), dtype=np.uint8)
    img = cv2.imdecode(file_bytes, cv2.IMREAD_COLOR)
    img_resized = cv2.resize(img, (224,224)) / 255.0
    st.image(img, caption='Uploaded Image', use_column_width=True)
    pred = model.predict(np.expand_dims(img_resized, axis=0))
    class_id = np.argmax(pred)
    st.write(f"Predicted Class: {class_id}")
