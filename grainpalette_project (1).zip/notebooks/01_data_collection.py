# 1: Data Collection
# Place and organize your rice grain images in the data/ folder manually or use this script to download dataset.
# (Add your dataset download or organization code here)
