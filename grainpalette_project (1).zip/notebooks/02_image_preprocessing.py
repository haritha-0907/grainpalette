# 2: Image Preprocessing
import os
import cv2

def preprocess_image(img_path, size=(224,224)):
    img = cv2.imread(img_path)
    img = cv2.resize(img, size)
    img = img / 255.0
    return img

# Example usage
if __name__ == "__main__":
    for fname in os.listdir('../data'):
        if fname.endswith('.jpg') or fname.endswith('.png'):
            img = preprocess_image(os.path.join('../data', fname))
