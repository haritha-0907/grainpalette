# 4: Save The Model
import tensorflow as tf
model = tf.keras.models.load_model('path_to_your_trained_model.h5')  # adjust path
model.save('../model/grainpalette_model.h5')
print("Model saved to model/grainpalette_model.h5")
