# 5: Application Building
# This script shows how to load the model and perform a prediction on a new image.
import tensorflow as tf
import cv2
import numpy as np

model = tf.keras.models.load_model('../model/grainpalette_model.h5')

def predict_image(img_path):
    img = cv2.imread(img_path)
    img = cv2.resize(img, (224,224)) / 255.0
    img = np.expand_dims(img, axis=0)
    preds = model.predict(img)
    return np.argmax(preds), preds

if __name__ == "__main__":
    label, probs = predict_image('../data/sample.jpg')
    print(f"Predicted class: {label}, Probabilities: {probs}")
